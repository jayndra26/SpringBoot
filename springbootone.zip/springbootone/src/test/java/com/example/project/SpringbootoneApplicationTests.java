package com.example.project;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.project.layer2.Applicant;
import com.example.project.layer2.Payee;
import com.example.project.layer3.ApplicantRepository;
import com.example.project.layer3.PayeeRepository;

@SpringBootTest
class SpringbootoneApplicationTests {
	
	@Autowired
	ApplicantRepository applicantRepository;
	@Autowired
	PayeeRepository payeeRepository;

	@Test
	void contextLoads() {
	}
	@Test
	void getApplicant() {
		List<Applicant> all = applicantRepository.findAllApp();
		System.out.println("All Account Size "+all.size());
		for (Applicant applicant : all) {
			System.out.println("Applicant ID "+applicant.getApplicantId());
			System.out.println("Applicant Name "+applicant.getApplicantName());
			System.out.println("Applicant Father Name]"+applicant.getApplicantFatherName());
			
		}

	}
	@Test
	void getPayee() {
		List<Payee> all = payeeRepository.findAllP();
				System.out.println("All Payee Size "+all.size());
				for (Payee payee : all) {
					System.out.println(payee.getPayeeid());
					System.out.println(payee.getPayeeacc());
					System.out.println(payee.getPayeeifsc());
					
				}
	}

}
