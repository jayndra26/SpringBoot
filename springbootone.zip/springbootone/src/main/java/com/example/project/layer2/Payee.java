package com.example.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;


@Component
@Entity 
@Table(name="payee_table_new")
@Getter
@Setter
public class Payee {

	@Id
	@Column(name="payee_id")
	private int payeeid;
	@NotBlank(message = "Payee Name Should Not Be Blank!!!")
	@Column(name="payee_name")
	private String payeename;
	@NotBlank(message = "Payee Account Should Not Be Blank!!!")
	@Size(min=0,max=11)
	@Column(name="payee_acc")
	private String payeeacc;
	@Pattern(message = "Invalid IFSC Code Please Check Again!!!",regexp="^[A-Za-z]{4}0[A-Z0-9a-z]{6}$")
	@Column(name="payee_ifsc")
	private String payeeifsc;
}
