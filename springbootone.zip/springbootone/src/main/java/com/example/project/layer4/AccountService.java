package com.example.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.project.layer2.Account;
@Service
public interface AccountService {
	public void createAccSer(Account a);
	public List<Account> getAll();
	public void getAcc(int no);
	public void updAccSer(Account a);
	public void rem(int no);

}
