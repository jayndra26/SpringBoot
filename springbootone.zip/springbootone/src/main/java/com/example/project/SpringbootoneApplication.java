package com.example.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootoneApplication.class, args);
	}

}
