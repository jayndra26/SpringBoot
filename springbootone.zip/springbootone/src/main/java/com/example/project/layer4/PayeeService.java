package com.example.project.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.project.layer2.Payee;

@Service
public interface PayeeService {
	void createP(Payee pa);
	void modifyP(Payee pa);
	void removeP(int pa);
	Payee findP(int pa);
	List<Payee> findAllP();	

}
