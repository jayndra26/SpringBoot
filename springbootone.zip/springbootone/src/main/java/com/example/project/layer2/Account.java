package com.example.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;


import lombok.Getter;
import lombok.Setter;

@Component
@Entity
@Table(name = "account_table_new")
@Getter
@Setter
public class Account {
	@Id
	@GeneratedValue
	@Column(name = "acc_no")
	private int accountNumber;
	
	@Column(name="acc_name")
	@NotBlank(message = "Account Holder Name may not be blank")
	private String accountHolderName;
	
	@Column(name="acc_bal")
	private int accountBalnce;

}
