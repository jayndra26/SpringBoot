package com.example.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;


@Component
@Entity
@Table(name = "applicant_table_new")
@Getter
@Setter
public class Applicant {
	
	@Id
	@Column(name = "applicant_id")

	private int applicantId;
	
	@Column(name = "applicant_mobile")
	@Size(min=0,max=10)
	private String mobileNumb;
	
	@Column(name="applicant_name")
	@NotBlank(message = "Applicant Name may not be blank")
	private String applicantName;
	
	
	@Column(name="applicant_father")
	private String applicantFatherName;
	
	@Column(name="applicant_mother")
	private String applicantMotherName;
	
	
	@Column(name="applicant_married")
	private String married;
	
		
	@Column(name="applicant_aadhar")
	private String aadhar;
	
	@Column(name="applicant_panCard")
	private String panCard;
	
	@Column(name="applicant_photo")
	private String photo;
	
	@Column(name="applicant_status")
	private String applicant_status;
	
	@Column(name="account_type")
	private String account_type;
	
	
	

}
