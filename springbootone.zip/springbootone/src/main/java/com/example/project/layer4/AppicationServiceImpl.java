package com.example.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.layer2.Applicant;
import com.example.project.layer3.ApplicantRepository;

@Service
public class AppicationServiceImpl implements ApplicationService {

	@Autowired
	ApplicantRepository applicantRepository;
	
	public void createAppSer(Applicant a) {
		// TODO Auto-generated method stub
		applicantRepository.createApp(a);
		
		
	}

	
	public List<Applicant> getAll() {
		// TODO Auto-generated method stub
		return  applicantRepository.findAllApp();
	}

	
	public void getApp(int no) {
		// TODO Auto-generated method stub;
		applicantRepository.findApp(no);
		
	}

	
	public void updAppSer(Applicant a) {
		// TODO Auto-generated method stub
		applicantRepository.modifyApp(a);
		
	}

	public void rem(int no) {
		// TODO Auto-generated method stub
		applicantRepository.removeApp(no);
		
	}

	
	

}
