package com.example.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.layer2.Applicant;
import com.example.project.layer4.ApplicationService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/applicants")
public class ApplicantController {
	
	@Autowired
	ApplicationService applicationService;

	public ApplicantController() {
		System.out.println("Applicant controller");
	}
	
	@GetMapping("/")
	public List<Applicant> getApps()
	{
		return applicationService.getAll();
	}
	
	@GetMapping("/get/{applicantId}")
	public Applicant getApp(@PathVariable("applicantId") int search)
	{
		List<Applicant> applicants = applicationService.getAll();
		boolean found =false;
		Applicant applicant = null;
		for (int i = 0; i < applicants.size(); i++) {
			applicant = applicants.get(i);
			if(applicant.getApplicantId()==search)
			{
				found =true;
				break;
			}
			
			
		}
		if(found) {
			return applicant;
		}
		else return null;
	}
	
	@PostMapping("/add")
	public String addApp(@RequestBody Applicant addApp)
	
	{
		List<Applicant> applicants = applicationService.getAll();
		boolean found =false;
		Applicant applicant = null;
		for (int i = 0; i < applicants.size(); i++) {
			applicant = applicants.get(i);
			if(applicant.getApplicantId()==addApp.getApplicantId())
			{
				found =true;
				break;
			}
			
			
		}
		if(found) {
			return "Object already Exists "+addApp;
		}
		else {
			applicationService.createAppSer(addApp);
			return "Object added Succesfully ";
		}
	}
	@PutMapping("/upd")
	public String updApplicant(@RequestBody Applicant appmodify)
	{
		List<Applicant> applicants = applicationService.getAll();
		boolean found =false;
		Applicant applicant = null;
		for (int i = 0; i < applicants.size(); i++) {
			applicant = applicants.get(i);
			if(applicant.getApplicantId()==appmodify.getApplicantId())
			{
				found =true;
				applicationService.rem(applicant.getApplicantId());
				applicationService.createAppSer(applicant);
				break;
			}
			
			
		}
		if(found) {
			return "object modified "+appmodify;
		}
		else
			return " object not found "+appmodify;
		
		
		
	}
	@DeleteMapping("/del/{applicantid}")
	public void delApp(@PathVariable("applicantid") int search) 
	{
		List<Applicant> applicants = applicationService.getAll();
		
		boolean found =false;
		Applicant applicant = null;
		for (int i = 0; i < applicants.size(); i++) {
			applicant = applicants.get(i);
			if(applicant.getApplicantId()==search)
			{
				found =true;
				
				break;
			}
			
			
		}
		if(found) {
			applicationService.rem(search);
			System.out.println("Applicant "+search+" is deleted successfully");
			applicationService.rem(search);
	}
	else
	{
		System.out.println("Applicant "+search+" is NOT FOUND");
	}
	

}
}
