package com.example.project.layer3;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepositoryImpl implements BaseRepository {
	@PersistenceContext
	EntityManager entityManager;
	

	public BaseRepositoryImpl() {
		System.out.println("BASEDAOImpl()......");
	}

	
	@Transactional
	public void persist(Object obj) {
		// TODO Auto-generated method stub
		entityManager.persist(obj);
		
	}

	@Transactional
	public void merge(Object obj) {
		// TODO Auto-generated method stub
		entityManager.merge(obj);

	}

	@Transactional
	public void remove(Object obj) {
		// TODO Auto-generated method stub
		entityManager.remove(obj);

	}

	
	public <AnyType> AnyType find(Class<AnyType> className, Serializable primaryKey) {
		// TODO Auto-generated method stub
		  AnyType e = entityManager.find(className, primaryKey);
		  return e;
	}

	
	@SuppressWarnings("unchecked")
	public <AnyType> List<AnyType> findAll(String entityName) {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery("from "+entityName);
		return query.getResultList();
	}

}
