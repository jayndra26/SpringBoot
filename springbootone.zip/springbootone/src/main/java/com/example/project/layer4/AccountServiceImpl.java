package com.example.project.layer4;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.layer2.Account;
import com.example.project.layer3.AccountRepository;


@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountRepository accountRepository;

	@Override
	public void createAccSer(Account a) {
		// TODO Auto-generated method stub
		accountRepository.createAccount(a);
		
	}

	@Override
	public List<Account> getAll() {
		// TODO Auto-generated method stub
		return accountRepository.findAllAccounts();	}

	@Override
	public void getAcc(int no) {
		// TODO Auto-generated method stub
		accountRepository.findAccount(no);
		
	}

	@Override
	public void updAccSer(Account a) {
		// TODO Auto-generated method stub
		accountRepository.modifyAccount(a);
		
	}

	@Override
	public void rem(int no) {
		// TODO Auto-generated method stub
		accountRepository.removeAccount(no);
		
	}
	
	
	
	
	
	
}

