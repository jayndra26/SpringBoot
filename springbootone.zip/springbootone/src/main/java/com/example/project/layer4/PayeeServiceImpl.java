package com.example.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.layer2.Payee;
import com.example.project.layer3.PayeeRepository;

@Service
public class PayeeServiceImpl implements PayeeService {
	
	@Autowired
	PayeeRepository payeeRepository;
	@Override
	public void createP(Payee pa) {
		// TODO Auto-generated method stub
		payeeRepository.createP(pa);

	}


	public void modifyP(Payee pa) {
		// TODO Auto-generated method stub
		payeeRepository.modifyP(pa);

	}


	public void removeP(int pa) {
		// TODO Auto-generated method stub
		payeeRepository.removeP(pa);

	}


	public Payee findP(int pa) {
		// TODO Auto-generated method stub
		return payeeRepository.findP(pa);
	}


	public List<Payee> findAllP() {
		// TODO Auto-generated method stub
		return payeeRepository.findAllP();
	}

}
