package com.example.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.layer2.Payee;
import com.example.project.layer4.PayeeService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/payees")
public class PayeeController {
	@Autowired
	PayeeService payeeService;
	
	@GetMapping("/")
	public List<Payee> getAll(){
		
		return payeeService.findAllP();
		
	}
	@GetMapping("/get/{payeeid}")
	public Payee getPayee(@PathVariable("payeeid") int search) {
		List<Payee>payees =payeeService.findAllP();
		boolean found = false;
		Payee payee =null;
		for (int i = 0; i < payees.size(); i++) {
			payee = payees.get(i);
			if(payee.getPayeeid()==search)
			{
				found =true;
				break;
			}
			
		}
		if (found)
			return payee;
		else return null;
	
	}
	@PostMapping("/upd")
	public String addPayee(@RequestBody Payee addPayee) {
		List<Payee>payees =payeeService.findAllP();
		boolean found = false;
		Payee payee =null;
		for (int i = 0; i < payees.size(); i++) {
			payee = payees.get(i);
			if(payee.getPayeeid()==addPayee.getPayeeid())
			{
				found =true;
				break;
			}
			
		}
		if (found)
			return "Object already Exists "+addPayee;
		else {
			payeeService.createP(addPayee);
			return "Object added Successfully";
		}
	
	}
	@PutMapping("/upd")
	public String updPayee(@RequestBody Payee modifyPayee) {
		List<Payee>payees =payeeService.findAllP();
		boolean found = false;
		Payee payee =null;
		for (int i = 0; i < payees.size(); i++) {
			payee = payees.get(i);
			if(payee.getPayeeid()==modifyPayee.getPayeeid())
			{
				found =true;
				payeeService.removeP(payee.getPayeeid());
				payeeService.createP(payee);
				break;
			}
			
		}
		if (found)
			return "Object modified "+modifyPayee;
		else {
			
			return "Object not found "+modifyPayee;
		}
	
	}
	
	@RequestMapping("/del/{payeeid}")
	public void delPayee(@PathVariable("payeeid") int search) {
		List<Payee>payees =payeeService.findAllP();
		boolean found = false;
		Payee payee =null;
		for (int i = 0; i < payees.size(); i++) {
			payee = payees.get(i);
			if(payee.getPayeeid()==search)
			{
				found =true;
				break;
			}
			
		}
		if (found) {
			payeeService.removeP(search);
			System.out.println("Payee "+search+" is deleted successfully");
		}
			
		
		else 
			System.out.println("Payee "+search+" is NOT FOUND");
	
	}
	
	
}

