package com.example.project.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.project.layer2.Account;
@Repository
public class AccountRepositoryImpl extends BaseRepositoryImpl  implements AccountRepository {

	@Transactional
	public void createAccount(Account account) {
		// TODO Auto-generated method stub
		super.persist(account);

	}

	@Transactional
	public void modifyAccount(Account account) {
		// TODO Auto-generated method stub
		super.merge(account);

	}

	@Transactional
	public void removeAccount(int acno) {
		// TODO Auto-generated method stub
		Account acc = super.find(Account.class, acno);
				super.remove(acc);

	}


	public Account findAccount(int acno) {
		// TODO Auto-generated method stub
		 return super.find(Account.class,acno);
	}

	
	public List<Account> findAllAccounts() {
		// TODO Auto-generated method stub
	
		return super.findAll("Account");
	}

}
