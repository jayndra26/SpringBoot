package com.example.project.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.project.layer2.Applicant;
@Repository
public class ApplicantRepositoryImpl extends BaseRepositoryImpl implements ApplicantRepository {

	@Transactional
	public void createApp(Applicant app) {
		// TODO Auto-generated method stub
		super.persist(app);

	}

	@Transactional
	public void modifyApp(Applicant app) {
		// TODO Auto-generated method stub
		super.merge(app);

	}

	@Transactional
	public void removeApp(int apno) {
		// TODO Auto-generated method stub
		Applicant applicant = super.find(Applicant.class, apno);
		super.remove(applicant);

	}

	
	public Applicant findApp(int apno) {
		// TODO Auto-generated method stub
		return super.find(Applicant.class, apno);
	}

	
	public List<Applicant> findAllApp() {
		// TODO Auto-generated method stub
		return super.findAll("Applicant");
	}

}
