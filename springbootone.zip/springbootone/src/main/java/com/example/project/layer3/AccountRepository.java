package com.example.project.layer3;

import java.util.List;

import com.example.project.layer2.Account;

public interface AccountRepository {
	void createAccount(Account account);
	void modifyAccount(Account account);
	void removeAccount(int acno);
	Account findAccount(int acno);
	List<Account> findAllAccounts();
	
	

}
