package com.example.project.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.project.layer2.Payee;
@Repository
public class PayeeRepositoryImpl extends BaseRepositoryImpl implements PayeeRepository {

	@Transactional
	public void createP(Payee pa) {
		// TODO Auto-generated method stub
		super.persist(pa);

	}

	@Transactional
	public void modifyP(Payee pa) {
		// TODO Auto-generated method stub
		super.merge(pa);

	}

	@Transactional
	public void removeP(int pa) {
		// TODO Auto-generated method stub
		Payee payee = super.find(Payee.class, pa);
				super.remove(payee);

	}


	public Payee findP(int pa) {
		// TODO Auto-generated method stub
		return super.find(Payee.class, pa);
	}


	public List<Payee> findAllP() {
		// TODO Auto-generated method stub
		return super.findAll("Payee");
	}

}
